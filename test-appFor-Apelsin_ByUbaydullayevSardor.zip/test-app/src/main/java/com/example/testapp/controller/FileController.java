package com.example.testapp.controller;

import com.example.testapp.dto.FileDto;
import com.example.testapp.model.Attachment;
import com.example.testapp.repo.AttachmentRepo;
import com.example.testapp.service.AttachmentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.net.MalformedURLException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;

@RestController
public class FileController {


    @Autowired
    AttachmentRepo attachmentRepo;
    @Autowired
    AttachmentService attachmentService;
    String filePath = "C:\\Users\\Sardor\\Desktop\\test-app\\src\\main\\resources";

    //1.Save file and return download link
    @PostMapping("/uploadFile")
    public ResponseEntity uploadFileToDb(@RequestParam("file") MultipartFile file) {
        String fileDownloadUri = attachmentService.uploadFile(file, filePath);
        return ResponseEntity.ok(fileDownloadUri);
    }

    /**
     * 2.return File(pageable)
     */
    @GetMapping("/getFiles/{pageNo}/{pageSize}")
    public ResponseEntity<List<FileDto>> getFiles(@PathVariable int pageNo, @PathVariable int pageSize) {
        List<FileDto> fileDtoList = attachmentService.getAllFiles(pageNo, pageSize);
        return ResponseEntity.ok(fileDtoList);
    }

    //return File By Time interval
    @GetMapping("/getFilesByTimeInterval/{month}/{month2}")
    public ResponseEntity<List<FileDto>> getFilesByInterval(@PathVariable int month, @PathVariable int month2) {

        List<FileDto> fileDtoList = attachmentService.getAllFilesByTimeInterval(month, month2);

        return ResponseEntity.ok(fileDtoList);
    }

    //return File By Size
    @GetMapping("/getFilesBySize/{inputSize1}/{inputSize2}")
    public ResponseEntity<List<FileDto>> getFilesBySize(@PathVariable int inputSize1, @PathVariable int inputSize2) {

        List<FileDto> fileDtoList = attachmentService.getAllFilesBySize(inputSize1, inputSize2);

        return ResponseEntity.ok(fileDtoList);
    }

    //return File By Name
    @GetMapping("/getFiles/{fileName}")
    public ResponseEntity<FileDto> getFile(@PathVariable String fileName) {
        FileDto fileDto = attachmentService.getFileByName(fileName);

        return ResponseEntity.ok(fileDto);
    }


    @GetMapping("/downloadFile/{fileName:.+}")
    public ResponseEntity downloadFileFromLocal(@PathVariable String fileName) {

        Attachment byGeneratedName = attachmentRepo.findByRealName(fileName);

        Path path = Paths.get(byGeneratedName.getFilePath());
        Resource resource = null;
        try {
            resource = new UrlResource(path.toUri());
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(byGeneratedName.getContentType()))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);

    }
}


