package com.example.testapp.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class FileDto {
   private String OriginalName;
   private Long sizeKb;
   private String uploadDate;
   private String downloadLink;

}
