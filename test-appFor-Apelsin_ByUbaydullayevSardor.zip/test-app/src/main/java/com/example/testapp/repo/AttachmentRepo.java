package com.example.testapp.repo;

import com.example.testapp.model.Attachment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AttachmentRepo extends JpaRepository<Attachment, Integer> {
    Attachment findByRealName(String name);


}
