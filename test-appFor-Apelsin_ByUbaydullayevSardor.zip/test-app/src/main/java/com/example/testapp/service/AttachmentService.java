package com.example.testapp.service;

import com.example.testapp.dto.FileDto;
import com.example.testapp.model.Attachment;
import com.example.testapp.repo.AttachmentRepo;
import org.apache.commons.io.FilenameUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

@Service

public class AttachmentService {

    @Autowired
    private AttachmentRepo attachmentRepo;

    public List<Attachment> findPaginated(int pageNo, int pageSize) {

        Pageable paging = PageRequest.of(pageNo, pageSize);
        Page<Attachment> pagedResult = attachmentRepo.findAll(paging);
        return pagedResult.toList();
    }

    public String uploadFile(MultipartFile file, String filePath) {
        String extension = FilenameUtils.getExtension(file.getOriginalFilename());

        Random random = new Random();
        Attachment attachment = new Attachment(
                null,
                file.getSize(),
                LocalDateTime.now(),
                filePath,
                file.getOriginalFilename(),
                String.format("%s%s", System.currentTimeMillis(), random.nextInt(100000)) + "." + extension,
                file.getContentType());
        String fileDownloadUri = "";
        try {
            LocalDateTime uploadTime = attachment.getUploadTime();
            int year = uploadTime.getYear();
            int month = uploadTime.getMonthValue();
            int day = uploadTime.getDayOfMonth();
            File file5 = new File(filePath + "\\uploads");
            if (!file5.exists()) {
                file5.mkdir();
            }
            File file1 = new File(file5 + "\\" + year);
            if (!file1.exists()) {
                file1.mkdir();
            }
            File file2 = new File(file1 + "\\" + month);
            if (!file2.exists()) {
                file2.mkdir();
            }
            File file3 = new File(file2 + "\\" + day);
            if (!file3.exists()) {
                file3.mkdir();
            }
            String newPath = file3 + "\\" + attachment.getGeneratedName();
            file.transferTo(new File(newPath));
            attachment.setFilePath(newPath);
            attachmentRepo.save(attachment);

            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/downloadFile/")
                    .path(attachment.getRealName())
                    .toUriString();
        } catch (IOException e) {
        }
        return fileDownloadUri;
    }

    public List<FileDto> getAllFiles(int pageNo, int pageSize) {
        List<Attachment> paginated = findPaginated(pageNo, pageSize);
        List<FileDto> fileDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");


        String fileDownloadUri = "";
        for (Attachment attachment : paginated) {
            long size = attachment.getSize();
            long sizeInKb = size / 1024;
            String formatDateTime = attachment.getUploadTime().format(formatter);

            fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                    .path("/downloadFile/")
                    .path(attachment.getRealName())
                    .toUriString();
            fileDtoList.add(new FileDto(attachment.getRealName(), sizeInKb, formatDateTime, fileDownloadUri));

        }
        return fileDtoList;
    }

    public List<FileDto> getAllFilesByTimeInterval(int month, int month2) {
        List<Attachment> attachmentList = attachmentRepo.findAll();
        ArrayList<FileDto> fileDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");


        String fileDownloadUri = "";

        for (Attachment attachment : attachmentList) {
            LocalDateTime uploadTime = attachment.getUploadTime();
            int uploadTimeMonth = uploadTime.getMonthValue();
            if (uploadTimeMonth >= month && uploadTimeMonth <= month2) {
                long size = attachment.getSize();
                long sizeInKb = size / 1024;
                String formatDateTime = attachment.getUploadTime().format(formatter);

                fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/downloadFile/")
                        .path(attachment.getRealName())
                        .toUriString();

                fileDtoList.add(new FileDto(attachment.getRealName(), sizeInKb, formatDateTime, fileDownloadUri));

            }
        }
        return fileDtoList;
    }

    public List<FileDto> getAllFilesBySize(int inputSize1, int inputSize2) {
        List<Attachment> attachmentList = attachmentRepo.findAll();
        ArrayList<FileDto> fileDtoList = new ArrayList<>();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

        String fileDownloadUri = "";

        for (Attachment attachment : attachmentList) {

            long size = attachment.getSize();
            long sizeInKb = size / 1024;
            long sizeInMb = sizeInKb / 1024;

            if (sizeInMb >= inputSize1 && sizeInMb <= inputSize2) {
                String formatDateTime = attachment.getUploadTime().format(formatter);

                fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                        .path("/downloadFile/")
                        .path(attachment.getRealName())
                        .toUriString();

                fileDtoList.add(new FileDto(attachment.getRealName(), sizeInKb, formatDateTime, fileDownloadUri));

            }

        }
        return fileDtoList;
    }

    public FileDto getFileByName(String fileName) {
        Attachment attachment = attachmentRepo.findByRealName(fileName);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
        long size = attachment.getSize();
        long sizeInKb = size / 1024;
        String formatDateTime = attachment.getUploadTime().format(formatter);
        String fileDownloadUri = ServletUriComponentsBuilder.fromCurrentContextPath()
                .path("/downloadFile/")
                .path(attachment.getRealName())
                .toUriString();
        FileDto fileDto = new FileDto(attachment.getRealName(), sizeInKb, formatDateTime, fileDownloadUri);
        return fileDto;
    }
}

